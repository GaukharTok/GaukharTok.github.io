const apiKey = "c5a5af82d198a4d436bfabfff4fce3c7";
const newUrl = `https://api.themoviedb.org/3/movie/popular?api_key=${apiKey}&language=en-US&page=1`;

// https://api.themoviedb.org/3/movie/popular?api_key=${apiKey}&language=en-US&page=1`

//

//
//

async function getMovies() {
  try {
    const {
      data: { results },
    } = await axios(newUrl + apiKey);
    console.log(results);
    const movieContainer = document.querySelector(".movies");
    results.forEach((movie) => {
      const button = `
<button id ="${movie.id}" class="movieBtn">${movie.title}</button>
<p>${movie.overview}</p>
<p>${movie.vote_average}</p>
`;
      movieContainer.insertAdjacentHTML("beforeend", button);
    });

    const btns = document.querySelectorAll(".movieBtn");
    btns.forEach((btn) => {
      btn.addEventListener("click", function () {
        // console.log(this.id);
        location.href = `moviePage.html?movieId =${this.id}`;
      });
    });
  } catch (error) {
    console.log(error);
  }
}
getMovies();

// function renderMovies() {
//   const container = document.getElementById("movie-container");
//   container.innerHTML = "";

//   movies.forEach((movie) => {
//     const movieElement = document.createElement("div");
//     movieElement.classList.add("movie");

//     movieElement.innerHTML = `
//                 <h2>${movie.title}</h2>
//                 <img src="${movie.poster_path}" alt="${movie.title}">
//                 <p>Genres: ${movie.genre.join(", ")}</p>
//                 <p>Rating: ${movie.vote_average}</p>
//                 <button onclick="addToFavorites(${
//                   movie.id
//                 })">Add to Favorites</button>`;

//     container.appendChild(movieElement);
//   });
// }
